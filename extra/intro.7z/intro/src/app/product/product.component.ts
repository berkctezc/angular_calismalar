//Bu componenti terminale >> ng g component product     yazarak olusturduk

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-product', //inline template "alt gr + ," --> `bunun arasına html kodlarımızı yazıyoruz`
  template: `<p>{{name}}</p>`,
  styleUrls: ['./product.component.css']
})
export class ProductComponent implements OnInit {

  constructor() { }
  name="Laptop"
  ngOnInit() {
  }

}
