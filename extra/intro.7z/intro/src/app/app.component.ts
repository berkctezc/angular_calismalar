import { Component } from '@angular/core';

@Component({
  selector: 'app-root', //cagirma ismi
  templateUrl: './app.component.html', //view olan html dosyamiz
  styleUrls: ['./app.component.css'] //dizi seklinde css alabiliriz
})
export class AppComponent {
  title = 'intro';  //viewden erisebilecegimiz variablelar ve functionlar
  firstName='Berkcan'

  //fonksiyon
}
